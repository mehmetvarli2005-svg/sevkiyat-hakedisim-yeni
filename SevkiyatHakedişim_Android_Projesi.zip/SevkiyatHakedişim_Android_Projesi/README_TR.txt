SEVKİYAT HAKEDİŞİM — ANDROID PROJE KAYNAĞI

Bu paket Android Studio ile APK oluşturmak için hazırlanmış kaynak projedir; doğrudan kurulabilir APK değildir.

APK oluşturma:
1. Bilgisayara Android Studio kur.
2. Bu ZIP dosyasını bilgisayarda bir klasöre çıkar.
3. Android Studio > Open ile içindeki proje klasörünü aç.
4. Gradle senkronizasyonunun bitmesini bekle. İstenirse Android SDK 35'i yükle.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
6. İşlem bitince "locate" bağlantısıyla APK'yı bul.
7. APK'yı telefona aktar, aç ve Android'in kurulum uyarılarını onayla.

Uygulama web ekranını cihaz içindeki HTML dosyasından açar; çalışması için internet gerekmez.
Kayıtlar Android WebView yerel depolamasında tutulur. Uygulama verilerini temizlemek veya uygulamayı kaldırmak kayıtları silebilir; uygulamadaki yedekleme özelliğini kullan.

Ücret tarifesi:
- 1,05 TL/km
- İlk tur için ek tur ücreti yok
- İkinci sefer +350 TL
- 7,50 TL/palet
- 120 TL/mağaza
- Yemek: 14.00–17.59: 260 TL; 18.00–19.59: 390 TL; 20.00–00.00: 520 TL
